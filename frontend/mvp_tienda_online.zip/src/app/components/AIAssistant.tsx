import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

export const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content: '¡Hola! Soy tu asesor de moda personal. ¿En qué puedo ayudarte hoy?',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const newUserMessage = { role: 'user' as const, content: inputValue };
    setMessages((prev) => [...prev, newUserMessage]);

    // Simulated AI response
    setTimeout(() => {
      const mockResponses = [
        'Para una ocasión casual, te recomendaría nuestros polos Essentials en colores neutros. Son versátiles y cómodos.',
        'Los shorts Active son perfectos para el verano. Están disponibles en varias tallas y colores.',
        'Si buscas algo para una ocasión especial, nuestras poleras premium tienen un corte elegante y moderno.',
        '¿Te gustaría que te ayude a encontrar algo específico? Puedo recomendarte productos según tu estilo.',
      ];
      const randomResponse = mockResponses[Math.floor(Math.random() * mockResponses.length)];

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: randomResponse },
      ]);
    }, 800);

    setInputValue('');
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-40 w-12 h-12 bg-foreground text-background border border-border/20 hover:scale-105 transition-transform flex items-center justify-center"
        aria-label="Abrir asistente de moda"
      >
        {isOpen ? (
          <X className="w-4 h-4" strokeWidth={1.5} />
        ) : (
          <MessageCircle className="w-4 h-4" strokeWidth={1.5} />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-8 z-40 w-80 h-96 bg-card border border-border/30 flex flex-col">
          {/* Header */}
          <div className="px-5 py-4 border-b border-border/30">
            <h3 className="text-xs font-light tracking-[0.2em] uppercase">
              Asesor de Estilo
            </h3>
            <p className="text-[10px] text-muted-foreground tracking-wider mt-1">
              Consultas y recomendaciones
            </p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[80%] px-4 py-3 text-xs leading-relaxed ${
                    message.role === 'user'
                      ? 'bg-foreground text-background'
                      : 'bg-muted/50 text-foreground border border-border/20'
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="px-5 py-4 border-t border-border/30">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Escribe tu consulta..."
                className="flex-1 px-3 py-2 bg-muted/30 border border-border/30 text-xs text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-foreground/30 transition-colors"
              />
              <button
                onClick={handleSendMessage}
                className="p-2 bg-foreground text-background hover:bg-foreground/90 transition-colors"
                aria-label="Enviar mensaje"
              >
                <Send className="w-3.5 h-3.5" strokeWidth={1.5} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
