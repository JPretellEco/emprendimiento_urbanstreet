export const Home = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - Full Screen */}
      <section className="relative h-screen flex items-center justify-center">
        <img
          src="https://images.unsplash.com/photo-1664817559603-3831ba34c112?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
          alt="Colección Essentials"
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-black/70" />
        <div className="relative z-10 text-center text-white px-6">
          <h1 className="text-6xl md:text-8xl font-light tracking-[0.3em] mb-8 leading-none uppercase">
            Esencial
            <br />
            Atemporal
          </h1>
          <p className="text-xs md:text-sm max-w-xl mx-auto leading-relaxed tracking-[0.2em] uppercase text-white/80">
            Diseño minimalista y calidad superior
            <br />
            para el estilo contemporáneo
          </p>
        </div>
      </section>

      {/* Asymmetric Grid Campaign Section */}
      <section className="py-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          {/* Left Column - Single Large Image */}
          <div className="relative h-[60vh] md:h-[85vh] overflow-hidden group">
            <img
              src="https://images.unsplash.com/photo-1631034527645-9c3a92b73abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Editorial principal"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90"
            />
            <div className="absolute inset-0 bg-black/30" />
          </div>

          {/* Right Column - Two Stacked Images */}
          <div className="flex flex-col">
            <div className="relative h-[40vh] md:h-[42.5vh] overflow-hidden group">
              <img
                src="https://images.unsplash.com/photo-1775816364124-b305f2b06ce7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Editorial 2"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90"
              />
              <div className="absolute inset-0 bg-black/30" />
            </div>
            <div className="relative h-[40vh] md:h-[42.5vh] overflow-hidden group">
              <img
                src="https://images.unsplash.com/photo-1640943136566-3edeb13e3d3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Editorial 3"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90"
              />
              <div className="absolute inset-0 bg-black/30" />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24">
        <h2 className="text-xs font-medium text-center mb-16 tracking-[0.3em] uppercase text-muted-foreground">
          Colecciones
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-1">
          <a
            href="/polos"
            className="group relative aspect-[3/4] overflow-hidden bg-card"
          >
            <img
              src="https://images.unsplash.com/photo-1775306413232-fecd45367613?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Polos"
              className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105 opacity-80"
            />
            <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors duration-300" />
            <div className="absolute inset-0 flex items-center justify-center">
              <h3 className="text-white text-2xl font-light tracking-[0.3em] uppercase">POLOS</h3>
            </div>
          </a>

          <a
            href="/shorts"
            className="group relative aspect-[3/4] overflow-hidden bg-card"
          >
            <img
              src="https://images.unsplash.com/photo-1619474221266-0e23ce248c60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Shorts"
              className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105 opacity-80"
            />
            <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors duration-300" />
            <div className="absolute inset-0 flex items-center justify-center">
              <h3 className="text-white text-2xl font-light tracking-[0.3em] uppercase">SHORTS</h3>
            </div>
          </a>

          <a
            href="/poleras"
            className="group relative aspect-[3/4] overflow-hidden bg-card"
          >
            <img
              src="https://images.unsplash.com/photo-1552571072-0eadf8e3953c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
              alt="Poleras"
              className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105 opacity-80"
            />
            <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors duration-300" />
            <div className="absolute inset-0 flex items-center justify-center">
              <h3 className="text-white text-2xl font-light tracking-[0.3em] uppercase">POLERAS</h3>
            </div>
          </a>
        </div>
      </section>
    </div>
  );
};
