import { Product } from '../types';

export const products: Product[] = [
  // POLOS
  {
    id: '1',
    name: 'Polo Essentials Negro',
    category: 'polos',
    price: 350.00,
    slug: 'polo-essentials-negro',
    colors: [
      { name: 'Negro', hex: '#000000', available: true },
      { name: 'Blanco', hex: '#FFFFFF', available: true },
      { name: 'Gris', hex: '#808080', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: false },
    ],
    images: [
      'https://images.unsplash.com/photo-1631034527645-9c3a92b73abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1631034528681-6b5e4c20b1e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1653694053345-b22f94c95bcf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Polo confeccionado en algodón pima de máxima calidad. Corte oversized contemporáneo. Construcción premium con costuras reforzadas. Silueta atemporal.',
  },
  {
    id: '2',
    name: 'Polo Premium Morado',
    category: 'polos',
    price: 380.00,
    slug: 'polo-premium-morado',
    colors: [
      { name: 'Morado', hex: '#B19CD9', available: true },
      { name: 'Azul Cielo', hex: '#87CEEB', available: true },
      { name: 'Verde', hex: '#90EE90', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1775816364124-b305f2b06ce7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1775306413232-fecd45367613?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Diseño minimalista con atención meticulosa al detalle. Tejido de peso medio. Acabados de lujo en cada costura. Esencial contemporáneo.',
  },
  {
    id: '3',
    name: 'Polo Urbano',
    category: 'polos',
    price: 340.00,
    slug: 'polo-urbano',
    colors: [
      { name: 'Beige', hex: '#F5F5DC', available: true },
      { name: 'Blanco', hex: '#FFFFFF', available: true },
    ],
    sizes: [
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1660891950285-71ed267bf04d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1648301558657-b55db298200a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Construcción de alta gama con silueta relajada. Tejido premium de larga duración. Filosofía less is more aplicada al diseño urbano.',
  },
  {
    id: '4',
    name: 'Polo Lifestyle',
    category: 'polos',
    price: 360.00,
    slug: 'polo-lifestyle',
    colors: [
      { name: 'Verde Oliva', hex: '#808000', available: true },
      { name: 'Azul Marino', hex: '#000080', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: false },
    ],
    images: [
      'https://images.unsplash.com/photo-1759596450534-0a960be607e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1671869239603-8d73133e0e5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Pieza versátil de guardarropa esencial. Materiales selectos con drapeado natural. Minimalismo elevado con máxima funcionalidad.',
  },

  // SHORTS
  {
    id: '5',
    name: 'Short Active Rojo',
    category: 'shorts',
    price: 280.00,
    slug: 'short-active-rojo',
    colors: [
      { name: 'Rojo', hex: '#FF0000', available: true },
      { name: 'Negro', hex: '#000000', available: true },
      { name: 'Azul Marino', hex: '#000080', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1640943136566-3edeb13e3d3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1619474221266-0e23ce248c60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Short técnico con estética minimalista. Tejido de alto rendimiento con tecnología de secado rápido. Diseño limpio sin logos visibles.',
  },
  {
    id: '6',
    name: 'Short Casual Beige',
    category: 'shorts',
    price: 260.00,
    slug: 'short-casual-beige',
    colors: [
      { name: 'Beige', hex: '#F5F5DC', available: true },
      { name: 'Verde', hex: '#90EE90', available: true },
    ],
    sizes: [
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: false },
    ],
    images: [
      'https://images.unsplash.com/photo-1694870115097-dc0ec53a9fb3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1695918428860-a3bc6a2f1d4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Corte contemporáneo con inspiración militar. Tejido resistente de calidad superior. Detalles premium en bolsillos y costuras.',
  },
  {
    id: '7',
    name: 'Short Training',
    category: 'shorts',
    price: 290.00,
    slug: 'short-training',
    colors: [
      { name: 'Negro', hex: '#000000', available: true },
      { name: 'Gris', hex: '#808080', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1619361814016-4acc36025fa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1747027887263-8974b74ded25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Construcción técnica con filosofía minimalista. Ergonomía estudiada para máximo confort. Estética depurada sin excesos.',
  },
  {
    id: '8',
    name: 'Short Sport Pro',
    category: 'shorts',
    price: 300.00,
    slug: 'short-sport-pro',
    colors: [
      { name: 'Verde', hex: '#008000', available: true },
      { name: 'Azul', hex: '#0000FF', available: true },
    ],
    sizes: [
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1733747660763-cb18f75ffc19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1649528282593-579f64e25ae2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Rendimiento superior con diseño atemporal. Materiales técnicos de última generación. Simplicidad elevada al máximo nivel.',
  },

  // POLERAS (T-SHIRTS)
  {
    id: '9',
    name: 'Polera Basic Negro',
    category: 'poleras',
    price: 220.00,
    slug: 'polera-basic-negro',
    colors: [
      { name: 'Negro', hex: '#000000', available: true },
      { name: 'Blanco', hex: '#FFFFFF', available: true },
      { name: 'Gris', hex: '#808080', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1552571072-0eadf8e3953c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1595188525947-4ba148279529?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'La esencia del minimalismo. Algodón premium de peso pesado. Construcción sin etiquetas exteriores. Básico perfeccionado.',
  },
  {
    id: '10',
    name: 'Polera Street Style',
    category: 'poleras',
    price: 240.00,
    slug: 'polera-street-style',
    colors: [
      { name: 'Blanco', hex: '#FFFFFF', available: true },
      { name: 'Beige', hex: '#F5F5DC', available: true },
    ],
    sizes: [
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: false },
    ],
    images: [
      'https://images.unsplash.com/photo-1595188525947-4ba148279529?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1759596450534-0a960be607e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Interpretación contemporánea del básico esencial. Tejido suave al tacto con caída natural. Atención al detalle en cada elemento.',
  },
  {
    id: '11',
    name: 'Polera Premium',
    category: 'poleras',
    price: 260.00,
    slug: 'polera-premium',
    colors: [
      { name: 'Azul', hex: '#4169E1', available: true },
      { name: 'Verde', hex: '#90EE90', available: true },
    ],
    sizes: [
      { size: 'S', available: true },
      { size: 'M', available: true },
      { size: 'L', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1740711152088-88a009e877bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1777793299588-8055f47cd20e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Diseño limpio con materiales excepcionales. Corte refinado oversized. Calidad superior en cada puntada. Lujo silencioso.',
  },
  {
    id: '12',
    name: 'Polera Summer',
    category: 'poleras',
    price: 230.00,
    slug: 'polera-summer',
    colors: [
      { name: 'Beige', hex: '#F5F5DC', available: true },
      { name: 'Blanco', hex: '#FFFFFF', available: true },
    ],
    sizes: [
      { size: 'M', available: true },
      { size: 'L', available: true },
      { size: 'XL', available: true },
    ],
    images: [
      'https://images.unsplash.com/photo-1778530207696-ea08486320d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      'https://images.unsplash.com/photo-1778530207547-04ad4aa9632a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    ],
    description: 'Ligereza y calidad en perfecta armonía. Tejido transpirable de verano. Silueta relajada con proporción estudiada. Simplicidad refinada.',
  },
];

// Helper functions
export const getProductById = (id: string): Product | undefined => {
  return products.find(p => p.id === id);
};

export const getProductBySlug = (slug: string): Product | undefined => {
  return products.find(p => p.slug === slug);
};

export const getProductsByCategory = (category: 'polos' | 'shorts' | 'poleras'): Product[] => {
  return products.filter(p => p.category === category);
};
